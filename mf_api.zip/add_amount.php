<?php include('./config.php');

$phone_number = $_REQUEST['phone_number'];
$amount = $_REQUEST['amount'];
$trans_details = $_REQUEST['trans_detail'];

$date = date('Y-m-d');
$time = date("H:i:s");
$today = date('Y-m-d h:i:s A');

// ================== STATUS ==================
$status = ($trans_details == "OTHER") ? '0' : '1';

// ================== INSERT REQUEST ==================
$sql = "INSERT INTO user_fund_request
(username, points, amount, trans_details, date, status)
VALUES ('$phone_number','','$amount','$trans_details','$date','$status')";

$insert = mysqli_query($con, $sql);

// ================== AUTO DEPOSIT ==================
$display_amount = ($status == '1') ? "+".$amount : $amount;

mysqli_query($con,"INSERT INTO user_auto_deposite
(username, transaction_note, amount, txt_date, status)
VALUES ('$phone_number','$trans_details','$display_amount','$today','$status')");

// ================== WALLET UPDATE ==================
if($status == '1'){

    $check = mysqli_query($con,"SELECT * FROM user_info WHERE phone='$phone_number'");

    if(mysqli_num_rows($check) > 0){

        $user = mysqli_fetch_array($check);
        $wallet = $user['wallet'];

        // 🔥 BONUS FETCH
        $offer = mysqli_fetch_assoc(mysqli_query($con,"
        SELECT * FROM fund_offers 
        WHERE min_amount <= '$amount' AND status=1
        ORDER BY min_amount DESC 
        LIMIT 1
        "));

        $bonus = 0;

        if($offer){
            $bonus = ($amount * $offer['bonus_percent']) / 100;
        }

        // 🔥 TOTAL
        $total_amount = $amount + $bonus;
        $new_wallet = $wallet + $total_amount;

        // 🔥 UPDATE WALLET
        mysqli_query($con,"
        UPDATE user_info SET wallet='$new_wallet' WHERE phone='$phone_number'
        ");

        // 🔥 HISTORY
        $remark = "Deposit + Bonus";
        $final_amount = "+".$total_amount;

        mysqli_query($con,"
        INSERT INTO wallet_history
        (status, date, time, amount, updated_amount, remark, phone_number)
        VALUES ('1','$date','$time','$final_amount','$new_wallet','$remark','$phone_number')
        ");
    }
}

// ================== RESPONSE ==================
if($insert){
    $result = array(
        'success' => '1',
        'msg' => 'Points Added Successfully!!'
    );
}else{
    $result = array(
        'success' => '0',
        'msg' => 'Some Error Occured!'
    );
}

echo json_encode($result);
?>