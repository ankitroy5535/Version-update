<?php

include './config.php'; // 🔥 DB connection yaha se

// headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// 🔥 QUERY
$sql = "SELECT DISTINCT category FROM quiz_data ORDER BY category ASC";

$result = mysqli_query($con, $sql);

// ✅ DATA FOUND
if($result && mysqli_num_rows($result) > 0){

    $categories = [];

    while ($row = mysqli_fetch_assoc($result)) {
        $categories[] = $row['category'];
    }

    echo json_encode([
        "success" => "1",
        "count" => count($categories),
        "categories" => $categories
    ]);

} else {

    // ❌ NO DATA
    echo json_encode([
        "success" => "0",
        "message" => "No categories found"
    ]);
}
?>