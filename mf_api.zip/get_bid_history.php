<?php

include './config.php';

header('Content-Type: application/json');

$username = $_REQUEST['phone_number'] ?? '';
$date1 = $_REQUEST['date1'] ?? '';
$date2 = $_REQUEST['date2'] ?? '';

// 🔴 VALIDATION
if($username == "" || $date1 == "" || $date2 == ""){
    echo json_encode([
        "success"=>"0",
        "msg"=>"phone_number, date1 and date2 required"
    ]);
    exit;
}

$sql = "SELECT * FROM user_bid_history 
        WHERE username='$username' 
        AND date BETWEEN '$date1' AND '$date2' 
        ORDER BY id DESC";

$res = mysqli_query($con, $sql);

$result = [];

while($row = mysqli_fetch_assoc($res))
{
    $date = date("j M Y", strtotime($row['date']));
    $time = date("h:i:s A", strtotime($row['time']));

    $game = $row['game_name'];
    $bid_date = $row['date'];

    // 🔍 RESULT FETCH
    $res_check = mysqli_fetch_assoc(mysqli_query($con,
        "SELECT * FROM result_chart 
         WHERE game_name='$game' AND date='$bid_date'"
    ));

    // DEFAULT
    $status = "Pending";
    $message = "⌛ Result Awaited";

    if($res_check){

        // 🎯 SINGLE DIGIT
        if($row['game_type'] == "Single Digit"){
            
            if($row['session'] == "Open" && $row['open_digit'] == $res_check['open_digit']){
                $status = "Win";
                $message = "🎉 Congratulations! You Won!";
            }
            elseif($row['session'] == "Close" && $row['close_digit'] == $res_check['close_digit']){
                $status = "Win";
                $message = "🎉 Congratulations! You Won!";
            }else{
                $status = "Loss";
                $message = "😔 Good Luck For Next Time!";
            }

        }

        // 🎯 JODI
        elseif($row['game_type'] == "Jodi"){

            $jodi = $res_check['open_digit'].$res_check['close_digit'];

            if($row['open_digit'] == $jodi){
                $status = "Win";
                $message = "🔥 Jackpot! You Hit the Jodi!";
            }else{
                $status = "Loss";
                $message = "😔 Better Luck Next Time!";
            }
        }

        // 🎯 PANA
        else{

            if($row['session'] == "Open" && $row['open_pana'] == $res_check['open_pana']){
                $status = "Win";
                $message = "🎉 Awesome! Pana Matched!";
            }
            elseif($row['session'] == "Close" && $row['close_pana'] == $res_check['close_pana']){
                $status = "Win";
                $message = "🎉 Awesome! Pana Matched!";
            }else{
                $status = "Loss";
                $message = "😔 Good Luck For Next Time!";
            }
        }
    }

    $result[] = [
        'bid_id' => $row['bid_id'],
        'game_name' => $row['game_name'],
        'game_type' => $row['game_type'],
        'session' => $row['session'],
        'open_pana' => $row['open_pana'],
        'open_digit' => $row['open_digit'],
        'close_pana' => $row['close_pana'],
        'close_digit' => $row['close_digit'],
        'points_action' => $row['points_action'],
        'status' => $status,
        'message' => $message,
        'date' => $date." ".$time
    ];
}

// FINAL RESPONSE
echo json_encode([
    "success"=>"1",
    "count"=>count($result),
    "data"=>$result
]);

?>