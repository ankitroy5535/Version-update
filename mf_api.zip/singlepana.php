<?php
header('Content-Type: application/json');

if(isset($_GET['phone_number'])){

    $phone = $_GET['phone_number'];

    if(strlen($phone) != 10){
        echo json_encode([
            "status" => false,
            "message" => "Invalid phone number"
        ]);
        exit;
    }

    $result = [];

    // Custom order array
    $order = [1,2,3,4,5,6,7,8,9,0];

    $n = count($order);

    for($a = 0; $a < $n; $a++){
        for($b = $a + 1; $b < $n; $b++){
            for($c = $b + 1; $c < $n; $c++){

                $i = $order[$a];
                $j = $order[$b];
                $k = $order[$c];

                $num = $i.$j.$k;

                // ank (sum last digit)
                $sum = $i + $j + $k;
                $ank = $sum % 10;

                $result[$ank][] = $num;
            }
        }
    }

    echo json_encode([
        "status" => true,
        "phone_number" => $phone,
        "data" => $result
    ]);

}else{
    echo json_encode([
        "status" => false,
        "message" => "phone_number is required"
    ]);
}