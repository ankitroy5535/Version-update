<?php include "./config.php";

$phone_number =   $_REQUEST['phone_number'];
$points =  $_REQUEST['amount'];
$remark = $_REQUEST['remark'];
$date = date("Y-m-d");
$day = date("l");
$limits = mysqli_fetch_array(
    mysqli_query($con, "SELECT * FROM admin_settings")
);
$wallet_check = mysqli_fetch_array(
    mysqli_query($con, "SELECT * FROM  user_info where phone='$phone_number'")
);
$day_check = mysqli_query(
    $con,
    "SELECT * FROM  withdraw_limit_days where name='$day' and status=1 and role='Days'"
);

$wallet_amount = $wallet_check["wallet"]; //1000
$fix_limit = $limits["min_wallet_amount"]; //500
$remanig_amount = trim($wallet_amount) - trim($fix_limit);
$min_limit = $limits["min_withdrawal"];
$max_limit = $limits["max_withdrawal"];
// $open_time = $limits["withdraw_open_time"];
// $close_time = $limits["withdraw_close_time"];
// $current_time = date("h:i");

$open_time = strtotime(date("Y-m-d") . " " . $limits["withdraw_open_time"]);
$close_time = strtotime(date("Y-m-d") . " " . $limits["withdraw_close_time"]);
$current_time = strtotime(date("Y-m-d H:i"));  // Using "H:i" for 24-hour format

// if (mysqli_num_rows($day_check) > 0) {
    if ($current_time >= $open_time && $current_time <= $close_time) {
        if ($points <= $max_limit && $points >= $min_limit) {
            if ($points <= $remanig_amount) {
                $sql = "INSERT INTO `user_withdraw_request`(`username`, `points`, `amount`,  `receipe_image`, `date`, `remark`, `status`) VALUES ('$phone_number','$points',' ','','$date','$remark','0')";

                $check_pass = mysqli_query(
                    $con,
                    "SELECT * FROM user_withdraw_request WHERE username = '$phone_number' AND (status = '0')"
                );
                if (mysqli_num_rows($check_pass) > 0) {
                    $result = [
                        "success" => "0",
                        "msg" => "Still pending your last request",
                    ];
                } else {
                    $insert = mysqli_query($con, $sql);
                    if ($insert) {
                        $result = [
                            "success" => "1",
                            "msg" => "Withdraw Request Added Successfully!!",
                        ];
                    } else {
                        $result = [
                            "success" => "0",
                            "msg" => "Some Error Occured! Try Again Later!!",
                        ];
                    }
                }
            } else {
                $result = [
                    "success" => "0",
                    "msg" =>
                        "Limit does not match!! Minimum Limit is " .
                        $remanig_amount,
                ];
            }
        } else {
            
            $result = [
                "success" => "0",
                "msg" =>
                    "Limit does not match!! Minimum Limit is " .
                    $min_limit .
                    " & Maximum Limit is " .
                    $max_limit,
            ];
        }
    } else {
          
        $result = [
            "success" => "0",
            "msg" =>
                "We are closed. Opening time " .
                $open_time .
                " Closing time" .
                $close_time,
        ];
    }
// } else {
//     $result = [
//         "success" => "0",
//         "msg" => "Withdraw Request Not Allow " . $day,
//     ];
// }
echo json_encode($result);
?>
