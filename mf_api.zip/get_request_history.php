<?php

include './config.php';

header('Content-Type: application/json');

$phone_number = $_REQUEST['phone_number'] ?? '';

// 🔴 VALIDATION
if($phone_number == ""){
    echo json_encode([
        "success"=>"0",
        "msg"=>"phone_number required"
    ]);
    exit;
}

$sql = "SELECT * FROM user_withdraw_request 
        WHERE username='$phone_number' 
        ORDER BY id DESC";

$res = mysqli_query($con, $sql);

$data = [];

while($row = mysqli_fetch_assoc($res))
{
    // 📅 DATE FORMAT
    $date = date("j M Y", strtotime($row['date']));

    // 🔥 STATUS CONVERT
    if($row['status'] == "0"){
        $status_text = "Pending";
        $message = "⏳ Your request is under review";
    }
    elseif($row['status'] == "1"){
        $status_text = "Approved";
        $message = "✅ Withdrawal approved";
    }
    else{
        $status_text = "Rejected";
        $message = "❌ Withdrawal rejected";
    }

    $data[] = [
        'points' => $row['points'],
        'remark' => $row['remark'],
        'date' => $date,
        'status' => $status_text,
        'message' => $message
    ];
}

// ✅ RESPONSE
if(count($data) > 0){
    echo json_encode([
        "success"=>"1",
        "count"=>count($data),
        "data"=>$data
    ]);
}else{
    echo json_encode([
        "success"=>"0",
        "msg"=>"No withdraw history found"
    ]);
}

?>