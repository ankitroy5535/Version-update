<?php
include './config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$username = $_POST['phone_number'] ?? '';
$date1 = $_POST['date1'] ?? '';
$date2 = $_POST['date2'] ?? '';

if($username == '' || $date1 == '' || $date2 == ''){
    echo json_encode([
        'success'=>'0',
        'msg'=>'Missing parameters'
    ]);
    exit;
}

// 🔥 ONLY WIN DATA
$sql = "SELECT * FROM galidisawar_win_history 
        WHERE username='$username' 
        AND status='win'
        AND date BETWEEN '$date1' AND '$date2'
        ORDER BY id DESC";

$res = mysqli_query($con,$sql);

$data = [];

while($row = mysqli_fetch_assoc($res)){
    $data[] = array(
        'id'=>$row['id'],
        'date'=>$row['date'],
        'game_name'=>$row['game_name'],
        'game_type'=>$row['game_type'],
        'left_digit'=>$row['left_digit'],
        'right_digit'=>$row['right_digit'],
        'points'=>$row['points'],
        'win_amount'=>$row['win_amount'],
        'status'=>$row['status']
    );
}

if(empty($data)){
    echo json_encode([
        'success'=>'0',
        'msg'=>'No Winning Data Found',
        'result'=>[]
    ]);
}else{
    echo json_encode([
        'success'=>'1',
        'msg'=>'Winning Data Found',
        'result'=>$data
    ]);
}
?>