
<?php include('./config.php');


    $user = $_REQUEST['phone_number'];

    $select = mysqli_query($con,"SELECT * FROM user_info WHERE phone = '$user'");
    $select_num = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM contact_detail"));
    $select_upi = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM admin_settings"));

    if(mysqli_num_rows($select) > 0){
        
            $check = mysqli_fetch_array($select);
            $mobile = $check['phone'];
            $data = array(
                'phone_number' => $mobile,
                'wallet' => $check['wallet'],
                'date' => $check['date'],
                'status' => $check['status'],
                'start_time' => '05:00',
                'admin_mobile'=>$select_num['mobile'],
                'admin_wp' => $select_num['wp_mobile'],
                'upi_name' => 'Kalyan',
                'upi_payment_id' => $select_upi['upi_payment_id'],
                'upi_phone' => $select_upi['phonepepay_upi'],
                'upi_google' => $select_upi['gpay_upi'],
                'alert_message' => $select_upi['alert_message'],
                'how_to_play' => $select_upi['how_to_play'],
                'm_pin' => $check['m_pin'],
                'min_limit'=>$select_upi['min_bid_amt'],
                'max_limit'=>$select_upi['max_bid_amt'],
                'share_url'=>$select_upi['app_link'],
                'share_message'=>$select_upi['content'],
              
                
 'withdraw_close_time'=>$select_upi['withdraw_open_time'],
                'withdraw_close_time'=>$select_upi['withdraw_close_time'],
 'min_withdraw'=>$select_upi['min_withdrawal'],
                'max_withdraw'=>$select_upi['max_withdrawal'],
                
                
                'min_deposite'=>$select_upi['min_deposite'],
                'max_deposite'=>$select_upi['max_deposite'],
                'barcode_payment_mode'=>$select_upi['barcode_payment_mode'],
                'payment_barcode_image'=>$select_upi['payment_barcode_image'],
'barcode_message'=>$select_upi['barcode_message'],
                'payment_upi_id'=>$select_upi['payment_upi_id']
            );
            $result = array(
                'success' => '1',
                'data' => $data
            );
        
    }else{
        $data = array(
            'admin_wp' => $select_num['wp_mobile'],
            'msg' => 'User Not Found!'
        );
        $result = array(
            'success' => '0',
            'data' => $data
        );
    }
    echo json_encode($result);
?>
