<?php include('./config.php');
 
$phone = $_POST['phone_number']; 

$delete =  mysqli_query($con,"UPDATE `user_info` SET  `status`='0' WHERE phone='".$phone."'");
    

if($delete){
   $result = array(
        'success' => '1',
        'msg' => 'Account Delete Successfully'
        );
}
else{
     $result = array(
        'success' => '0',
        'msg' => 'Some Error Occured! Try Again Later'
        );
     
}

echo json_encode($result);
?>