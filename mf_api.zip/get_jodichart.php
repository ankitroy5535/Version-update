<?php

include('./config.php');

header('Content-Type: application/json');

if(isset($_GET['games_name'])){

    $games_name = mysqli_real_escape_string($con, $_GET['games_name']);

    $sql = "SELECT * FROM result_chart WHERE game_name='$games_name' ORDER BY date DESC";
    $res = mysqli_query($con, $sql);

    $result = [];

    if(mysqli_num_rows($res) > 0){

        while($row = mysqli_fetch_assoc($res)){

            $open_digit  = $row['open_digit'];
            $close_digit = $row['close_digit'];

            // ✅ Jodi banayi
            $jodi = $open_digit . $close_digit;

            $result[] = [
                'game_name'   => $row['game_name'],
                'result_date' => $row['date'],
                'jodi'        => $jodi
            ];
        }

        echo json_encode([
            "status" => true,
            "count"  => count($result),
            "data"   => $result
        ]);

    } else {

        echo json_encode([
            "status" => false,
            "message" => "No result found"
        ]);
    }

} else {

    echo json_encode([
        "status" => false,
        "message" => "games_name is required"
    ]);
}