<?php 
include('./config.php');

$user = $_REQUEST['phone_number'];

$select = mysqli_query($con,"SELECT * FROM user_info WHERE phone = '$user'");

if(mysqli_num_rows($select) > 0){
    
    $check = mysqli_fetch_array($select);

    $data = array(
        'phone_number' => $check['phone'],
        'name' => $check['name'],
        'email' => $check['email'],
        'wallet' => $check['wallet'],

        // UPI
        'phonepay' => $check['phonepay'],
        'googlepay' => $check['googlepay'],
        'paytm' => $check['paytm'],

        // BANK DETAILS
        'bank_name' => $check['bank_name'],
        'account_holder_name' => $check['account_holder_name'],
        'account_number' => $check['account_number'],
        'ifsc_code' => $check['ifsc_code'],

        // ✅ REFERRAL ADD
        'referral_code' => $check['referral_code'],
        'referred_by' => $check['referred_by'],

        'betting_status' => $check['betting_status'],
        'status' => $check['status'],
        'date' => $check['date'],
    );

    $result = array(
        'success' => '1',
        'data' => $data
    );

}else{

    $result = array(
        'success' => '0',
        'data' => array('msg' => 'User Not Found!')
    );
}

echo json_encode($result);
?>