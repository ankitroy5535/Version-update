<?php

include './config.php'; // 🔥 yaha se DB connection aayega

// headers
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// input
$category = isset($_GET['category']) ? trim($_GET['category']) : null;

if (!$category) {
    http_response_code(400);
    echo json_encode(["error" => "Category parameter is required"]);
    exit;
}

// 🔥 PREPARED QUERY (same tera wala)
$sql = $con->prepare("SELECT id, question, answer, category, option1, option2, option3, option4 
                      FROM quiz_data 
                      WHERE category = ?");

$sql->bind_param("s", $category);
$sql->execute();

$result = $sql->get_result();

if ($result->num_rows > 0) {

    $data = [];

    while ($row = $result->fetch_assoc()) {

        $data[] = [
            "id" => $row['id'],
            "question" => $row['question'],
            "answer" => $row['answer'], // (optional: remove later for security)
            "category" => $row['category'],
            "options" => [
                $row['option1'],
                $row['option2'],
                $row['option3'],
                $row['option4']
            ]
        ];
    }

    echo json_encode([
        "success" => "1",
        "data" => $data
    ]);

} else {

    echo json_encode([
        "success" => "0",
        "message" => "No data found for category: ".$category
    ]);
}

$sql->close();
?>