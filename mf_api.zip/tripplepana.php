<?php
header('Content-Type: application/json');

if(isset($_GET['phone_number'])){

    $phone = $_GET['phone_number'];

    if(strlen($phone) != 10){
        echo json_encode([
            "status" => false,
            "message" => "Invalid phone number"
        ]);
        exit;
    }

    $result = [];

    // Custom order
    $order = [1,2,3,4,5,6,7,8,9,0];

    foreach($order as $digit){

        // triple number
        $num = $digit.$digit.$digit;

        // ank (sum last digit)
        $sum = $digit + $digit + $digit;
        $ank = $sum % 10;

        $result[$ank][] = $num;
    }

    echo json_encode([
        "status" => true,
        "phone_number" => $phone,
        "data" => $result
    ]);

}else{
    echo json_encode([
        "status" => false,
        "message" => "phone_number is required"
    ]);
}