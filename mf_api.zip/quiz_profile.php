<?php
include './config.php';

$phone = $_REQUEST['phone_number'];

// 🔥 TOTAL QUIZ
$total_quiz = mysqli_fetch_assoc(mysqli_query($con,
"SELECT COUNT(*) as total FROM quiz_result WHERE phone_number='$phone'"
));

// 🔥 TOTAL SCORE
$total_score = mysqli_fetch_assoc(mysqli_query($con,
"SELECT SUM(score) as score FROM quiz_result WHERE phone_number='$phone'"
));

// 🔥 CORRECT / WRONG
$correct = mysqli_fetch_assoc(mysqli_query($con,
"SELECT COUNT(*) as total FROM user_answers WHERE phone_number='$phone' AND status='correct'"
));

$wrong = mysqli_fetch_assoc(mysqli_query($con,
"SELECT COUNT(*) as total FROM user_answers WHERE phone_number='$phone' AND status='wrong'"
));

// 🔥 TOTAL QUESTIONS
$total_questions = $correct['total'] + $wrong['total'];

// 🔥 ACCURACY
$accuracy = $total_questions > 0 ? round(($correct['total']/$total_questions)*100) : 0;

// 🔥 RESPONSE
echo json_encode([
    "success"=>"1",
    "data"=>[
        "total_quiz_played"=>$total_quiz['total'],
        "total_score"=>$total_score