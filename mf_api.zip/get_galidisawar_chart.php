<?php

include './config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$sql = "SELECT * FROM galidisawar_result_chart ORDER BY id DESC";
$res = mysqli_query($con,$sql);

$result = array();

while($row = mysqli_fetch_assoc($res))
{
    // ✅ Left = open digit
    $left_digit = $row['open_digit'];

    // ✅ Right = close digit
    $right_digit = $row['close_digit'];

    // ✅ Jodi (optional)
    $jodi = $left_digit . $right_digit;

    $result[] = array(
        'game_name'   => $row['game_name'],
        'result_date' => $row['date'],
        'left_digit'  => $left_digit,
        'right_digit' => $right_digit,
        'jodi'        => $jodi
    );
}

echo json_encode([
    'success' => '1',
    'result'  => $result
]);

?>