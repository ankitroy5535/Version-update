<?php 
include('./config.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

$content = file_get_contents('php://input'); 	
$json = json_decode($content, true);

foreach ($json as $key => $value) {

    $phone_number = mysqli_real_escape_string($con,$value['phone_number']);
    $game_name = mysqli_real_escape_string($con,$value['game_name']);
    $game_type = mysqli_real_escape_string($con,$value['game_type']);
    $open_dig = $value['left_digit'];
    $close_dig = $value['right_digit'];
    $points_action = (int)$value['points_action'];

    // 🔥 SETTINGS
    $limits = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM admin_settings"));
    $min_limit = $limits['min_bid_amt'];
    $max_limit = $limits['max_bid_amt'];

    // ✅ AMOUNT VALIDATION
    if($points_action < $min_limit || $points_action > $max_limit){
        echo json_encode([
            'success'=>'0',
            'msg'=>"Bid must be between $min_limit and $max_limit"
        ]);
        exit;
    }

    // ✅ DIGIT VALIDATION (0–9 or empty)
    if(
        ($open_dig !== "" && !preg_match('/^[0-9]$/', $open_dig)) ||
        ($close_dig !== "" && !preg_match('/^[0-9]$/', $close_dig))
    ){
        echo json_encode([
            'success'=>'0',
            'msg'=>'Only single digit (0-9) allowed!'
        ]);
        exit;
    }

    // 🔥 NULL FIX (NO MORE NA ❌)
    $open_digit = ($open_dig === "" || $open_dig === "NA") ? NULL : $open_dig;
    $close_digit = ($close_dig === "" || $close_dig === "NA") ? NULL : $close_dig;

    $date = date('Y-m-d');
    $time = date("H:i:s");

    // 👤 USER CHECK
    $val = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM user_info WHERE phone = '$phone_number'"));

    if(!$val){
        echo json_encode([
            'success'=>'0',
            'msg'=>'User not found'
        ]);
        exit;
    }

    $bal = $val['wallet'];

    // 💰 WALLET CHECK
    if(($bal - $points_action) < 0){
        echo json_encode([
            'success'=>'0',
            'msg'=>'Insufficient Fund'
        ]);
        exit;
    }

    // 🔥 FINAL INSERT (NULL SAFE)
    $sql = "INSERT INTO galidisawar_bid_history 
    (username, game_name, game_type, left_digit, right_digit, points_action, date, time) 
    VALUES 
    ('$phone_number','$game_name','$game_type',
    ".($open_digit === NULL ? "NULL" : "'$open_digit'").",
    ".($close_digit === NULL ? "NULL" : "'$close_digit'").",
    '$points_action','$date','$time')";

    $insert = mysqli_query($con, $sql);

    if($insert){

        $amount = $bal - $points_action;

        // 💰 UPDATE WALLET
        mysqli_query($con,"UPDATE user_info SET wallet='$amount' WHERE phone='$phone_number'");

        // 📜 WALLET HISTORY
        mysqli_query($con,"INSERT INTO wallet_history 
        (status, date, time, amount, updated_amount, remark, phone_number) 
        VALUES 
        ('0','$date','$time','$points_action','$amount','Deduct for Bid','$phone_number')");

        echo json_encode([
            'success'=>'1',
            'msg'=>'Bid Added Successfully'
        ]);
    }else{
        echo json_encode([
            'success'=>'0',
            'msg'=>'Insert Failed: '.mysqli_error($con)
        ]);
    }
}
?>