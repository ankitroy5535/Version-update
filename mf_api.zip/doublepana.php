<?php
header('Content-Type: application/json');

if(isset($_GET['phone_number'])){

    $result = [];

    // Custom order
    $order = [1,2,3,4,5,6,7,8,9,0];
    $priority = array_flip($order);

    foreach($order as $a){
        foreach($order as $b){

            if($a == $b) continue;

            // ONLY this condition
            if($priority[$b] > $priority[$a]){

                // ONLY this format
                $num = $a.$b.$b;

                $sum = $a + $b + $b;
                $ank = $sum % 10;

                $result[$ank][] = $num;
            }
        }
    }

    // clean duplicates
    foreach($result as $k => $v){
        $result[$k] = array_values(array_unique($v));
    }

    ksort($result);

    echo json_encode([
        "status" => true,
        "data" => $result
    ]);
}