<?php 
include('./config.php');

header('Content-Type: application/json');

// INPUTS
$user_name = mysqli_real_escape_string($con, $_REQUEST['user_name'] ?? '');
$user_phone = mysqli_real_escape_string($con, $_REQUEST['user_phone'] ?? '');
$user_password = mysqli_real_escape_string($con, $_REQUEST['user_password'] ?? '');
$user_mpin = mysqli_real_escape_string($con, $_REQUEST['user_mpin'] ?? '');
$user_email = mysqli_real_escape_string($con, $_REQUEST['user_email'] ?? '');
$token_id = mysqli_real_escape_string($con, $_REQUEST['token_id'] ?? '');
$referral_input = mysqli_real_escape_string($con, $_REQUEST['referral_code'] ?? '');

$date = date('Y-m-d');
$time = date('H:i:s');
$today = date('Y-m-d H:i:s');

// VALIDATION
if($user_name == "" || $user_phone == "" || $user_password == ""){
    echo json_encode(["success"=>"0","msg"=>"All fields are required"]);
    exit;
}

if(!preg_match('/^[0-9]{10}$/', $user_phone)){
    echo json_encode(["success"=>"0","msg"=>"Invalid phone number"]);
    exit;
}

if(strlen($user_password) < 6){
    echo json_encode(["success"=>"0","msg"=>"Password must be at least 6 characters"]);
    exit;
}

// CHECK USER EXISTS
$check = mysqli_query($con,"SELECT * FROM user_info WHERE phone='$user_phone'");
if(mysqli_num_rows($check) > 0){
    echo json_encode(["success"=>"0","msg"=>"User already registered"]);
    exit;
}

// STATUS
$select_activation = mysqli_fetch_array(mysqli_query($con,"SELECT status FROM activate_rule"));
$status = ($select_activation['status'] == "1") ? "1" : "0";

// BLOCKED NAMES
$blocked_words = ["john","doe","playcnx","cnxplay","John"];
$name_lower = strtolower($user_name);

foreach($blocked_words as $word){
    if(strpos($name_lower, $word) !== false){
        $status = "0";
        break;
    }
}

// BONUS
$limits = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM admin_settings"));
$bonus = $limits['Dragon_bonus'];

// 👉 GENERATE REFERRAL CODE
$ref_code = substr(md5(time()),0,6);

// 👉 CHECK REFERRAL VALID
$referred_by = '';
if(!empty($referral_input)){
    $check_ref = mysqli_query($con,"SELECT * FROM user_info WHERE referral_code='$referral_input'");
    if(mysqli_num_rows($check_ref) > 0){
        $referred_by = $referral_input;
    }
}

// 👉 INSERT USER (FINAL)
$insert = mysqli_query($con,"
INSERT INTO user_info 
(name, phone, password, m_pin, email, wallet, date, status, transfer_status, referral_code, referred_by, first_deposit) 
VALUES 
('$user_name','$user_phone','$user_password','$user_mpin','$user_email','$bonus','$today','$status','0','$ref_code','$referred_by','0')
");

if(!$insert){
    echo json_encode(["success"=>"0","msg"=>"Registration failed"]);
    exit;
}

// WALLET BONUS HISTORY
if($bonus > 0){
    mysqli_query($con,"
    INSERT INTO wallet_history 
    (status, date, time, amount, updated_amount, note, phone_number) 
    VALUES 
    ('1','$date','$time','$bonus','$bonus','Welcome Bonus','$user_phone')
    ");
}

// DEVICE TOKEN
$check_token = mysqli_query($con,"SELECT * FROM device_token WHERE mobile='$user_phone'");
if(mysqli_num_rows($check_token) > 0){
    mysqli_query($con,"UPDATE device_token SET token_id='$token_id' WHERE mobile='$user_phone'");
}else{
    mysqli_query($con,"INSERT INTO device_token (mobile,token_id,status) VALUES ('$user_phone','$token_id','1')");
}

// FETCH USER
$user = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM user_info WHERE phone='$user_phone'"));

// RESPONSE
$data = [
    'phone_number' => $user['phone'],
    'name' => $user['name'],
    'email' => $user['email'],
    'm_pin' => $user['m_pin'],
    'wallet' => $user['wallet'],
    'status' => $user['status'],
    'referral_code' => $user['referral_code'], // 👈 important
    'phonepay' => $user['phonepay'],
    'googlepay' => $user['googlepay'],
    'paytm' => $user['paytm']
];

echo json_encode([
    "success"=>"1",
    "msg"=>"Registered successfully",
    "data"=>$data
]);
?>