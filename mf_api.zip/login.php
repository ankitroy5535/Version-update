<?php 
include('./config.php');

header('Content-Type: application/json');

$user = $_REQUEST['phone_number'] ?? '';
$password = $_REQUEST['password'] ?? '';
$token_id = $_REQUEST['token_id'] ?? '';

// 🔴 VALIDATION
if($user == "" || $password == ""){
    echo json_encode([
        "success" => "0",
        "msg" => "Phone number and password required"
    ]);
    exit;
}

// 🔍 USER CHECK
$query = mysqli_query($con,"SELECT * FROM user_info WHERE phone='$user'");
if(mysqli_num_rows($query) == 0){
    echo json_encode([
        "success" => "0",
        "msg" => "User not found"
    ]);
    exit;
}

$userData = mysqli_fetch_assoc($query);

// 🔐 PASSWORD CHECK
if($userData['password'] != $password){
    echo json_encode([
        "success" => "0",
        "msg" => "Incorrect password"
    ]);
    exit;
}



// 🔔 TOKEN UPDATE
$check_token = mysqli_query($con,"SELECT * FROM device_token WHERE mobile='$user'");

if(mysqli_num_rows($check_token) > 0){
    mysqli_query($con,"UPDATE device_token SET token_id='$token_id' WHERE mobile='$user'");
}else{
    mysqli_query($con,"INSERT INTO device_token (mobile,token_id,status) VALUES ('$user','$token_id','1')");
}

// ✅ SUCCESS RESPONSE
$data = array(
    'phone_number' => $userData['phone'],
    'name' => $userData['name'],
    'email' => $userData['email'],
    'm_pin' => $userData['m_pin'],
    'wallet' => $userData['wallet'],
    'status' => $userData['status'],
    'phonepay' => $userData['phonepay'],
    'googlepay' => $userData['googlepay'],
    'paytm' => $userData['paytm']
);

echo json_encode([
    "success" => "1",
    "msg" => "Login successful",
    "data" => $data
]);
?>