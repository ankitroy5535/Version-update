<?php
header('Content-Type: application/json');

// Check phone_number parameter
if(isset($_GET['phone_number'])){

    $phone = $_GET['phone_number'];

    // Optional: validation (10 digit)
    if(strlen($phone) != 10){
        echo json_encode([
            "status" => false,
            "message" => "Invalid phone number"
        ]);
        exit;
    }

    // Generate numbers 00 to 99
    $numbers = [];
    for($i = 0; $i <= 99; $i++){
        $numbers[] = str_pad($i, 2, "0", STR_PAD_LEFT);
    }

    echo json_encode([
        "status" => true,
        "phone_number" => $phone,
        "data" => $numbers
    ]);

}else{
    echo json_encode([
        "status" => false,
        "message" => "phone_number is required"
    ]);
}