<?php 
include('./config.php');

$phone = $_REQUEST['phone_number'];

$bank_name = $_REQUEST['bank_name'];
$account_holder = $_REQUEST['account_holder_name'];
$account_number = $_REQUEST['account_number'];
$ifsc = $_REQUEST['ifsc_code'];

// existing data nikaal lo
$select = mysqli_fetch_array(mysqli_query($con,"SELECT * FROM user_info WHERE phone = '$phone'"));

// agar empty hai to old value use karo
if($bank_name == ""){
    $bank_name = $select['bank_name'];
}

if($account_holder == ""){
    $account_holder = $select['account_holder_name'];
}

if($account_number == ""){
    $account_number = $select['account_number'];
}

if($ifsc == ""){
    $ifsc = $select['ifsc_code'];
}

// update query
$update = mysqli_query($con,"UPDATE user_info SET 
    bank_name = '$bank_name',
    account_holder_name = '$account_holder',
    account_number = '$account_number',
    ifsc_code = '$ifsc'
    WHERE phone = '$phone'");

if($update){
    $result = array(
        'success' => '1',
        'msg' => 'Bank Details Updated Successfully'
    );
}else{
    $result = array(
        'success' => '0',
        'msg' => 'Some Error Occured! Try Again Later'
    );
}

echo json_encode($result);
?>