<?php

$response = array(
    "version_code" => 2,
    "version_name" => "1.1",
    "force_update" => true,
    "apk_url" => "https://matka-fun.io/matka_fun.apk",
    "message" => "New update available"
);

echo json_encode($response);

?>