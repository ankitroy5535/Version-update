<?php

include './config.php';

header('Content-Type: application/json');

$phone_number = $_REQUEST['phone_number'];
$date1 = $_REQUEST['date1'];
$date2 = $_REQUEST['date2'];

$sql = "SELECT * FROM wallet_history 
        WHERE phone_number='$phone_number' 
        AND date BETWEEN '$date1' AND '$date2'
        AND (
            remark LIKE '%Added%' 
            OR remark LIKE '%UPI%' 
            OR remark LIKE '%Bonus%' 
            OR remark LIKE '%Admin%'
        )
        ORDER BY id DESC";

$res = mysqli_query($con, $sql);

$data = [];

while($row = mysqli_fetch_assoc($res)){

    $date = date("j M Y", strtotime($row['date']));
    $time = date("h:i:s A", strtotime($row['time']));

    $data[] = [
        'amount' => $row['amount'],
        'updated_amount' => $row['updated_amount'],
        'remark' => $row['remark'],
        'datetime' => $date." ".$time
    ];
}

if(count($data) > 0){
    echo json_encode([
        "success" => "1",
        "data" => $data
    ]);
}else{
    echo json_encode([
        "success" => "0",
        "msg" => "No deposit history found"
    ]);
}
?>