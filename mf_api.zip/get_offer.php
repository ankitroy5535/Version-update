<?php

// 🔥 ERROR SHOW (important for debug)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 🔥 CONFIG PATH (IMPORTANT - adjust if needed)
include('./config.php'); 

// 🔥 CHECK DB CONNECTION
if(!$con){
    echo json_encode([
        "success" => "0",
        "msg" => "Database not connected"
    ]);
    die;
}

// 🔥 QUERY
$query = "SELECT * FROM offers ORDER BY id DESC";
$get = mysqli_query($con, $query);

// 🔥 QUERY ERROR
if(!$get){
    echo json_encode([
        "success" => "0",
        "msg" => mysqli_error($con)
    ]);
    die;
}

// 🔥 DATA ARRAY
$data = [];

while($row = mysqli_fetch_assoc($get)){

    $data[] = [
        "id" => $row['id'],
        "title" => $row['title'],
        "description" => $row['description'],
        "image" => $row['image'],
        "status" => $row['status']
    ];
}

// 🔥 FINAL RESPONSE
if(count($data) > 0){
    echo json_encode([
        "success" => "1",
        "total" => count($data),
        "data" => $data
    ]);
}else{
    echo json_encode([
        "success" => "0",
        "msg" => "No offers found"
    ]);
}

?>