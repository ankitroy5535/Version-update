<?php 
include "./config.php";

header('Content-Type: application/json');

$phone_number = $_REQUEST['phone_number'] ?? '';
$points = $_REQUEST['amount'] ?? 0;
$remark = $_REQUEST['remark'] ?? '';

$date = date("Y-m-d");
$day = date("l");

// 🔴 BASIC VALIDATION
if($phone_number == "" || $points == ""){
    echo json_encode([
        "success" => "0",
        "msg" => "Phone number and amount required"
    ]);
    exit;
}

// 🔴 SETTINGS
$limits = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM admin_settings"));
$user = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM user_info WHERE phone='$phone_number'"));

if(!$user){
    echo json_encode([
        "success" => "0",
        "msg" => "User not found"
    ]);
    exit;
}

// 🔴 WALLET CALCULATION
$wallet_amount = $user["wallet"];
$fix_limit = $limits["min_wallet_amount"];
$remaining_amount = $wallet_amount - $fix_limit;

$min_limit = $limits["min_withdrawal"];
$max_limit = $limits["max_withdrawal"];

// 🔴 TIME CHECK
$open_time = strtotime(date("Y-m-d") . " " . $limits["withdraw_open_time"]);
$close_time = strtotime(date("Y-m-d") . " " . $limits["withdraw_close_time"]);
$current_time = strtotime(date("Y-m-d H:i"));

// ❌ TIME CLOSED
if ($current_time < $open_time || $current_time > $close_time) {
    echo json_encode([
        "success" => "0",
        "msg" => "Withdraw closed! Open: ".$limits["withdraw_open_time"]." Close: ".$limits["withdraw_close_time"]
    ]);
    exit;
}

// ❌ LIMIT CHECK
if ($points < $min_limit) {
    echo json_encode([
        "success" => "0",
        "msg" => "Minimum withdrawal amount is ₹".$min_limit
    ]);
    exit;
}

if ($points > $max_limit) {
    echo json_encode([
        "success" => "0",
        "msg" => "Maximum withdrawal amount is ₹".$max_limit
    ]);
    exit;
}

// ❌ WALLET CHECK
if ($points > $remaining_amount) {
    echo json_encode([
        "success" => "0",
        "msg" => "Insufficient balance! You can withdraw max ₹".$remaining_amount
    ]);
    exit;
}

// ❌ PENDING REQUEST CHECK
$check_pending = mysqli_query($con,
    "SELECT * FROM user_withdraw_request WHERE username='$phone_number' AND status='0'"
);

if(mysqli_num_rows($check_pending) > 0){
    echo json_encode([
        "success" => "0",
        "msg" => "Your previous withdrawal request is still pending"
    ]);
    exit;
}

// ✅ INSERT
$sql = "INSERT INTO user_withdraw_request 
(username, points, amount, receipe_image, date, remark, status) 
VALUES ('$phone_number','$points','','','$date','$remark','0')";

$insert = mysqli_query($con, $sql);

if($insert){
    echo json_encode([
        "success" => "1",
        "msg" => "Withdraw request submitted successfully"
    ]);
}else{
    echo json_encode([
        "success" => "0",
        "msg" => "Database error! Try again later"
    ]);
}
?>