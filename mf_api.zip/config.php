


<?php
// ================= CORS =================
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

// ================= TIMEZONE =================
date_default_timezone_set('Asia/Kolkata');

// ================= DATABASE CONFIG =================
// ❌ localhost galat hai (DB dusri hosting par hai)
// ✅ DB wali hosting ka domain ya IP use karo

define('DB_HOST', '127.0.0.1'); 
// better option: database server ka IP address

define('DB_USER', 'u811186921_newbharat');
define('DB_PASSWORD', 'u811186921@Newbharat'); // 🔴 yahan NAYA password
define('DB_NAME', 'u811186921_newbharat');

// ================= CONNECTION =================
$con = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

if (!$con) {
    die('Failed connect: ' . mysqli_connect_error());
}
?>