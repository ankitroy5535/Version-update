<?php

function sendNotification($con, $phone, $title, $message){

    $date = date('Y-m-d');
    $time = date('H:i:s');

    mysqli_query($con,"
        INSERT INTO notifications 
        (phone_number, title, message, date, time) 
        VALUES 
        ('$phone','$title','$message','$date','$time')
    ");
}